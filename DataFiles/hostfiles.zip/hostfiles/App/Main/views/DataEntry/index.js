﻿(function() {
    angular.module('app').controller('app.views.dataentry.index', [
        '$scope', '$modal', 'abp.services.app.ticket',
        function ($scope, $modal, ticketService) {
            var vm = this;

            vm.brands = [];
            vm.products = [];
            vm.problems = [];

            function getDateEntries() {
                ticketService.getDataEntries({}).success(function (result) {
                    vm.brands = result.brands;
                    vm.products = result.products;
                    vm.problems = result.problems;
                });
            }

            vm.openBrandCreationModal = function() {
                var modalInstance = $modal.open({
                    templateUrl: '/App/Main/views/dataentry/brand.cshtml',
                    controller: 'app.views.dataentry.brandModal as vm',
                    backdrop: 'static'
                });

                modalInstance.result.then(function () {
                    getDateEntries();
                });
            };


            vm.openProductCreationModal = function () {
                var modalInstance = $modal.open({
                    templateUrl: '/App/Main/views/dataentry/product.cshtml',
                    controller: 'app.views.dataentry.productModal as vm',
                    backdrop: 'static'
                });

                modalInstance.result.then(function () {
                    getDateEntries();
                });
            };

            vm.openProblemCreationModal = function () {
                var modalInstance = $modal.open({
                    templateUrl: '/App/Main/views/dataentry/problem.cshtml',
                    controller: 'app.views.dataentry.problemModal as vm',
                    backdrop: 'static'
                });

                modalInstance.result.then(function () {
                    getDateEntries();
                });
            };


            //load all entries
            getDateEntries();
        }
    ]);
})();